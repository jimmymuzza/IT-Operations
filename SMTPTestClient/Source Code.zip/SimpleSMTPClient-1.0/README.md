# SimpleSMTPClient
Simple to the point quick SMTP Test Client.  
1. Runs on Windows
2. Supports Basic Authentication to SMTP Server
3. Supports anonymous connection to SMTP Server

![Image of Software](https://github.com/CodeCowboyOrg/SimpleSMTPClient/blob/master/source/SimpleSmtpClient/SimpleSMTPClient.jpg)

